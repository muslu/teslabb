import os, sys
from django.core.handlers.wsgi import WSGIHandler

sys.path.append('/home/muslu/django/teslabb/')
sys.path.append('/home/muslu/django/teslabb/teslabb/')

os.environ['DJANGO_SETTINGS_MODULE'] = 'settings'
application = WSGIHandler()
